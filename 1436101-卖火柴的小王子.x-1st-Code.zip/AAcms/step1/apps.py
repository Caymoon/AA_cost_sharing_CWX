from __future__ import unicode_literals

from django.apps import AppConfig


class Step1Config(AppConfig):
    name = 'step1'
